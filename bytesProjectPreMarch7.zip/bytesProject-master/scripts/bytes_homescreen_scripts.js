$(document).ready(function(){

  var visible = 0;

    $("#byteHomeButton").click(function(){
      if(visible == 0){
          $("#byteDropdown").show();
      }
      $visible = 1;
    });

    $("#byteHomeButton").click(function(){
      if(visible == 1){
          $("#byteDropdown").hide();
      }
      $visible = 0;
    });

});
